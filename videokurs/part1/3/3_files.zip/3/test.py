print('Hello, World!')
print('Привет, мир!!!')
