print('Hello, World!')
print('Hello, World 2!')
