# block comment
print('Hello, World 1!')
print('Hello, World 2!')  # inline comment

''' One-line docstring '''
""" One-line docstring """

''' Multi-line
docstring '''

""" Multi-line
docstring """
