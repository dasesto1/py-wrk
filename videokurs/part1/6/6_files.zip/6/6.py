import keyword

print(keyword.kwlist)

s = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis sem vel lacus pharetra feugiat ut ac tellus. Donec lobortis urna augue, rutrum commodo sem condimentum ut.'

num_1 = 10
_num = 10

hello = 'HI'

print(s)
print(hello)
print(num_1)

x = 100
price = 100
# tsena = 10

active_user = 'TEST'

# def = 10

DB_USER = 'root'
print(DB_USER)
DB_USER = 20
print(DB_USER)

y = 10
Y = 20
print(y, Y)
